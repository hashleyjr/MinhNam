package javagame;




public class windows {

	public static int WIDTH = 1920;

	public static int HEIGHT = 1080 ;

}